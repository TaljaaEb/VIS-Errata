### 3. Install & Run Commands (Linux Terminal)
Run these commands inside your `~/Desktop/VIS/` folder:

```bash
mkdir -p ~/Desktop/VIS/silent-bug-sphere/src
cd ~/Desktop/VIS/silent-bug-sphere

# After saving the 4 files into their respective paths:
npm install
npm run dev
