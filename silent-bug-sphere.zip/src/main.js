import './style.css';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const UNION_OPERATORS = ['remove', 'neglect', 'ignore', 'misuse', 'exempt', 'cancel', 'withdraw'];
const FLAW_DOMAINS = [
  'Control Flow & Logic Flaws',
  'Type Coercion & Value Quirks',
  'Asynchronous & Memory Pitfalls'
];

class SilentBugEngine {
  constructor() {
    this.isTorment = true;
    this.entropy = 0.5;
    this.activeDomain = FLAW_DOMAINS[0];
    this.activeOperator = 'none';
    this.lastArtifact = '0.30000000000000004';
    this.leakedCache = new WeakMap();
    this.pendingTimers = [];
  }

  torment(domainIndex) {
    this.isTorment = true;
    this.activeDomain = FLAW_DOMAINS[domainIndex % FLAW_DOMAINS.length];
    this.activeOperator = 'none (unmitigated)';
    this.entropy = Math.min(1.0, this.entropy + 0.25);

    if (domainIndex % 3 === 0) {
      let flag = false;
      if (flag = true) {
        let unreachable = (10 > 20 && 10 < 5);
        this.lastArtifact = `assign=true | dead=${unreachable}`;
      }
    } else if (domainIndex % 3 === 1) {
      const floatDrift = 0.1 + 0.2;
      const silentNaN = Number("void") * 42;
      const coercion = ([] == ![]);
      this.lastArtifact = `${floatDrift} | ${silentNaN} | []==![]->${coercion}`;
    } else {
      const unawaited = new Promise((resolve) => resolve('STALE_STATE'));
      const timerId = setTimeout(() => {}, 60000);
      this.pendingTimers.push(timerId);
      this.lastArtifact = `Promise{<pending>} | timers:${this.pendingTimers.length}`;
    }
  }

  heal(operatorIndex) {
    this.isTorment = false;
    const op = UNION_OPERATORS[operatorIndex % UNION_OPERATORS.length];
    this.activeOperator = op;
    this.entropy = Math.max(0.12, this.entropy - 0.22);

    switch (op) {
      case 'remove':
        while (this.pendingTimers.length) clearTimeout(this.pendingTimers.pop());
        this.lastArtifact = 'Purged timer references';
        break;
      case 'neglect':
        const safeVal = (Number("void") * 42) || 0;
        this.lastArtifact = `NaN bypassed -> ${safeVal}`;
        break;
      case 'ignore':
        Promise.resolve().catch(() => {});
        this.lastArtifact = 'Swallowed noise safely';
        break;
      case 'misuse':
        const snapped = ((0.1 + 0.2) * 10 | 0) / 10;
        this.lastArtifact = `Bitwise snap -> ${snapped}`;
        break;
      case 'exempt':
        let tempNode = { state: 'corrupt' };
        this.leakedCache.set(tempNode, true);
        tempNode = null;
        this.lastArtifact = 'WeakMap GC exemption';
        break;
      case 'cancel':
        const controller = new AbortController();
        controller.abort();
        this.lastArtifact = `Aborted: ${controller.signal.aborted}`;
        break;
      case 'withdraw':
        const guard = false && (10 > 20);
        this.lastArtifact = `Short-circuit exit: ${guard}`;
        break;
    }
  }
}

const engine = new SilentBugEngine();
const elRenderer = document.getElementById('rendererMode');
const elPhase = document.getElementById('phase');
const elDomain = document.getElementById('domain');
const elOperator = document.getElementById('operator');
const elArtifact = document.getElementById('artifact');
const elLog = document.getElementById('log');

function addLog(msg) {
  const line = document.createElement('div');
  line.textContent = `> ${msg}`;
  elLog.prepend(line);
  if (elLog.children.length > 18) elLog.removeChild(elLog.lastChild);
}

function hasWebGL() {
  try {
    const c = document.createElement('canvas');
    return !!(window.WebGLRenderingContext && (c.getContext('webgl') || c.getContext('experimental-webgl')));
  } catch (e) {
    return false;
  }
}

let innerMatRef = null;
let cycleStep = 0;

function stepEngine() {
  if (cycleStep % 10 < 3) {
    engine.torment(cycleStep);
    elPhase.textContent = 'TORMENT (Injecting Silent Entropy)';
    elPhase.className = 'torment';
    if (innerMatRef) innerMatRef.color.setHex(0xff2a2a);
    addLog(`[TORMENT] ${engine.activeDomain} -> ${engine.lastArtifact}`);
  } else {
    engine.heal(cycleStep);
    elPhase.textContent = 'HEAL (Union Operator Active)';
    elPhase.className = 'heal';
    if (innerMatRef) innerMatRef.color.setHex(0x00e676);
    addLog(`[HEAL:${engine.activeOperator.toUpperCase()}] ${engine.lastArtifact}`);
  }
  elDomain.textContent = engine.activeDomain;
  elOperator.textContent = engine.activeOperator;
  elArtifact.textContent = engine.lastArtifact;
  cycleStep++;
}

document.getElementById('togglePhase').addEventListener('click', () => {
  cycleStep = engine.isTorment ? 3 : 0;
  stepEngine();
});

document.getElementById('injectSpike').addEventListener('click', () => {
  engine.entropy = 1.25;
  addLog('[SPIKE] Silent NaN & float drift amplified!');
});

if (hasWebGL()) {
  elRenderer.textContent = 'Three.js WebGL (Local Bundle)';
  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x050508, 0.035);

  const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 100);
  camera.position.set(0, 0, 8.5);

  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  document.body.appendChild(renderer.domElement);

  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;

  const PALETTE = [
    new THREE.Color(0xff2a2a),
    new THREE.Color(0x0088ff),
    new THREE.Color(0x00e676),
    new THREE.Color(0xff9100),
    new THREE.Color(0xffea00)
  ];

  const outerGeo = new THREE.IcosahedronGeometry(2.6, 4);
  const posAttr = outerGeo.attributes.position;
  const basePositions = new Float32Array(posAttr.array);
  const colors = new Float32Array(posAttr.count * 3);

  for (let i = 0; i < posAttr.count; i++) {
    const c = PALETTE[i % PALETTE.length];
    colors[i * 3] = c.r;
    colors[i * 3 + 1] = c.g;
    colors[i * 3 + 2] = c.b;
  }
  outerGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

  const outerMat = new THREE.MeshBasicMaterial({
    vertexColors: true,
    wireframe: true,
    transparent: true,
    opacity: 0.85
  });
  const outerSphere = new THREE.Mesh(outerGeo, outerMat);
  scene.add(outerSphere);

  const innerGeo = new THREE.OctahedronGeometry(1.35, 2);
  const innerMat = new THREE.MeshBasicMaterial({
    color: 0xffea00,
    wireframe: true,
    transparent: true,
    opacity: 0.65
  });
  innerMatRef = innerMat;
  const innerSphere = new THREE.Mesh(innerGeo, innerMat);
  scene.add(innerSphere);

  const ASCII_GLYPHS = ['NaN', '0x0', '&&', '||', '==', '!=', 'void', 'true', 'null', '~', '^', '{}', '[]', '??'];
  const HEX_PALETTE = ['#ff2a2a', '#0088ff', '#00e676', '#ff9100', '#ffea00'];
  const asciiSprites = [];

  function createAsciiSprite(text, colorHex) {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    ctx.font = 'bold 28px Courier New';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = colorHex;
    ctx.fillText(text, 64, 32);

    const texture = new THREE.CanvasTexture(canvas);
    const material = new THREE.SpriteMaterial({ map: texture, transparent: true, opacity: 0.9 });
    const sprite = new THREE.Sprite(material);
    sprite.scale.set(1.1, 0.55, 1);
    return sprite;
  }

  for (let i = 0; i < 85; i++) {
    const sprite = createAsciiSprite(
      ASCII_GLYPHS[i % ASCII_GLYPHS.length],
      HEX_PALETTE[i % HEX_PALETTE.length]
    );
    const phi = Math.acos(-1 + (2 * i) / 85);
    const theta = Math.sqrt(85 * Math.PI) * phi;
    sprite.userData = { baseRadius: 3.3 + (i % 3) * 0.45, phi, theta, speed: 0.3 + (i % 5) * 0.12 };
    scene.add(sprite);
    asciiSprites.push(sprite);
  }

  const clock = new THREE.Clock();
  function animate() {
    requestAnimationFrame(animate);
    const t = clock.getElapsedTime();
    engine.entropy += ((engine.isTorment ? 0.65 : 0.15) - engine.entropy) * 0.03;

    const positions = outerGeo.attributes.position.array;
    const colorArr = outerGeo.attributes.color.array;

    for (let i = 0; i < posAttr.count; i++) {
      const ix = i * 3;
      const bx = basePositions[ix], by = basePositions[ix + 1], bz = basePositions[ix + 2];
      const wave1 = Math.sin(bx * 2.2 + t * 3.5) * Math.cos(by * 2.2 + t * 2.8);
      const wave2 = Math.sin(bz * 3.1 - t * 4.2);
      const displacement = 1 + (wave1 * 0.6 + wave2 * 0.4) * engine.entropy * 0.45;

      positions[ix] = bx * displacement;
      positions[ix + 1] = by * displacement;
      positions[ix + 2] = bz * displacement;

      const c = PALETTE[Math.floor((i + t * (engine.isTorment ? 18 : 6)) % PALETTE.length)];
      colorArr[ix] = c.r;
      colorArr[ix + 1] = c.g;
      colorArr[ix + 2] = c.b;
    }

    outerGeo.attributes.position.needsUpdate = true;
    outerGeo.attributes.color.needsUpdate = true;
    outerSphere.rotation.y = t * 0.25;
    outerSphere.rotation.x = Math.sin(t * 0.4) * 0.2;
    innerSphere.rotation.y = -t * 0.6;
    innerSphere.rotation.z = t * 0.4;

    asciiSprites.forEach((sprite, idx) => {
      const { baseRadius, phi, theta, speed } = sprite.userData;
      const r = baseRadius + Math.sin(t * 2 + idx) * engine.entropy * 0.6;
      const currentTheta = theta + t * speed * (engine.isTorment ? 1.4 : 0.5);
      sprite.position.set(
        r * Math.sin(phi) * Math.cos(currentTheta),
        r * Math.cos(phi),
        r * Math.sin(phi) * Math.sin(currentTheta)
      );
    });

    controls.update();
    renderer.render(scene, camera);
  }

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  stepEngine();
  setInterval(stepEngine, 2400);
animate();
} else {
elRenderer.textContent = '2D Wireframe Fallback (WebGL Disabled)';
const canvas = document.createElement('canvas');
document.body.appendChild(canvas);
const ctx = canvas.getContext('2d');
const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
window.addEventListener('resize', resize);
resize();
const HEX_PALETTE = ['#ff2a2a', '#0088ff', '#00e676', '#ff9100', '#ffea00'];
const GLYPHS = ['NaN', '0x0', '&&', '||', '==', 'void', 'true', 'null', '{}', '[]'];
let t = 0;
function draw2DFallback() {
requestAnimationFrame(draw2DFallback);
t += 0.025;
engine.entropy += ((engine.isTorment ? 0.65 : 0.15) - engine.entropy) * 0.03;
ctx.fillStyle = 'rgba(5, 5, 8, 0.35)';
ctx.fillRect(0, 0, canvas.width, canvas.height);
const cx = canvas.width / 2 + 120;
const cy = canvas.height / 2;
const baseR = Math.min(canvas.width, canvas.height) * 0.28;
for (let ring = 0; ring < 8; ring++) {
ctx.beginPath();
ctx.strokeStyle = HEX_PALETTE[ring % HEX_PALETTE.length];
ctx.lineWidth = 1.5;
for (let a = 0; a <= Math.PI * 2 + 0.1; a += 0.12) {
const wobble = Math.sin(a * 5 + t * 4 + ring) * engine.entropy * 45;
const rx = (baseR + wobble) * Math.cos(a + t * 0.3 * (ring % 2 ? 1 : -1));
const ry = (baseR + wobble) * Math.sin(a) * Math.cos(ring * 0.35 + t * 0.4);
if (a === 0) ctx.moveTo(cx + rx, cy + ry);
else ctx.lineTo(cx + rx, cy + ry);
}
ctx.stroke();
}
ctx.font = 'bold 14px Courier New';
for (let i = 0; i < 36; i++) {
const angle = (i / 36) * Math.PI * 2 + t * 0.5;
const dist = baseR * 1.25 + Math.sin(t * 3 + i) * engine.entropy * 35;
ctx.fillStyle = HEX_PALETTE[i % HEX_PALETTE.length];
ctx.fillText(GLYPHS[i % GLYPHS.length], cx + Math.cos(angle) * dist, cy + Math.sin(angle) * dist);
}
}
stepEngine();
setInterval(stepEngine, 2400);
draw2DFallback();
}
