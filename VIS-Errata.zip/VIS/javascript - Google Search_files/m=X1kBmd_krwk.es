loaded_h_0(function(_){var window=this;
_.v("X1kBmd");
var G3E=_.Kb(_.aBt,[0,_.Bld]);
_.gg(_.m9a,class extends _.Ao{static Sa(){return{service:{xi:_.kK}}}constructor(a){super();this.xi=a.service.xi}prefetch(a){return this.xi.prefetch(a)}showViewerLite(a){var b=a.getInteractionContext?.();a={H_:a.getClickTimestamp?.(),viewerType:a.getViewerType(),modalityOverride:a.getModalityOverride?(0,_.r9d)(a.getModalityOverride()):void 0,entrypoint:a.getEntrypoint(),interactionVed:a.getInteractionVed(),iy:b!==void 0?_.FYa(new _.lq,b):void 0,HGa:a.getReplaceContainingViewer(),contentPluginType:a.getContentPluginType(),
Daa:a.getSerializedPluginData(),KCb:!!a.getUseDomSwipeGroup?.(),aT:a.getSerializedCloseConfig?(0,_.l9d)(a.getSerializedCloseConfig()):void 0,contentId:a.getContentId?.(),A4:a.getDisableEntrypointMorph?.(),shellStyleClass:a.getShellStyleClass?.(),jH:a.getSerializedSwipeConfig?G3E(a.getSerializedSwipeConfig()):void 0};return this.xi.showViewerLite(a)}});
_.x();
});
// Google Inc.
