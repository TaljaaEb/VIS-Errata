loaded_h_0(function(_){var window=this;
_.Jtu=_.y("xuUld",[]);
_.v("xuUld");
var KTv=class extends _.Ls{constructor(a){super(a.Ma)}nFb(){return Promise.resolve()}};KTv.prototype.$wa$Ce1QC=function(){return this.nFb};_.Rs(_.Jtu,KTv);
_.x();
});
// Google Inc.
