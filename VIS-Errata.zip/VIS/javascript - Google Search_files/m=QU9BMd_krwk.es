loaded_h_0(function(_){var window=this;
_.v("QU9BMd");
var C3E=class{constructor(a){this.state=a}getId(){return this.state.id}getPushId(){return this.state.pushId}getUrl(){return this.state.url}getUserData(){return this.state.userData}};
_.gg(_.R8a,class extends _.Ao{static Sa(){return{service:{history:_.htb}}}constructor(a){super();this.history=a.service.history;this.Hx=document.body;this.ka=new Map;this.history.addListener((b,c,d)=>{if(d.Jga)for(let e of d.Jga)if(this.ka.has(e.id)){let f=this.ka.get(e.id);f&&_.Ce(()=>{f(e.ENa)});this.ka.delete(e.id)}d.userInitiated&&this.Hx.dispatchEvent(new CustomEvent("FWkcec"))})}pushAsync(a,b,c,d){a=d?this.history.ka(a,b):this.history.pushAsync(a,b);return Promise.resolve(a.then(e=>{c&&this.ka.set(e.id,
c);return e.id}))}pop(a,b){a=b?this.history.Aa(a):this.history.pop(a);return Promise.resolve(a.then(c=>c?new C3E(c):null))}getState(){var a=this.history.getState();return a?new C3E(a):null}getCurrentUrl(){return this.history.getCurrentUrl()}getEventTarget(){return this.Hx}navigate(a,b){a=this.history.navigate(a,b).committed;return Promise.resolve(a.then(c=>new C3E(c)))}});
_.x();
});
// Google Inc.
