loaded_h_0(function(_){var window=this;
_.v("sNsSob");
_.gg(_.s9a,class extends _.Ao{static Sa(){return{service:{Xx:_.jv}}}constructor(a){super();this.Xx=a.service.Xx}isAvailable(){return this.Xx.isAvailable()}isInBasicMode(){return this.Xx.isInBasicMode()}wasBasicModeLastRequested(){return this.Xx.wasBasicModeLastRequested()}async enterBasicMode(a){var b=(0,_.Tf)(),c=b();b=b(1);try{b(await c(this.Xx.enterBasicMode(a)))}finally{c()}}async exitBasicMode(a){var b=(0,_.Tf)(),c=b();b=b(1);try{b(await c(this.Xx.exitBasicMode(a)))}finally{c()}}async restoreToPreviousState(a){var b=
(0,_.Tf)(),c=b();b=b(1);try{b(await c(this.Xx.restoreToPreviousState(a)))}finally{c()}}});
_.x();
});
// Google Inc.
