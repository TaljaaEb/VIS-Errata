loaded_h_0(function(_){var window=this;
_.uFe=function(){return _.Lm("center_col")};
_.vFe=function(){return _.HLa("rcnt")};_.wFe=function(){return _.vFe()||_.uFe()};
var kHe,iHe;_.jHe=function(){return document.querySelector("[jsname=xcvsnc]")?document.querySelector("[jsname=xcvsnc]"):_.Ldb?document.querySelector("[data-st-tgt=fb"):_.Km(iHe)};_.lHe=function(a,b){var c=_.jHe();c?kHe(c,a,b):_.vFe()&&_.lg(_.Om("rfiSsc"),d=>{kHe(d,a,b,!0)})};
kHe=function(a,b,c,d=!1){a=_.Mm("A",a);for(let f of a){if(d&&(f.classList.contains("zItAnd")&&!f.classList.contains("FOU1zf")||f.classList.contains("nPDzT")&&!f.classList.contains("LatpMc")))break;if(a=f.getAttribute("href"))if(a.startsWith("/url")&&b==="q"){var e=_.ld(a,"q");if(!e)continue;e=_.md(e,b,c);f.setAttribute("href",_.md(a,"q",e))}else f.setAttribute("href",_.md(a,b,c))}};iHe=_.vFe()?"pTwnEc":"hdtb-sc";
_.v("pnOULd");
_.gg(_.$3a,class extends _.Ao{static Sa(){return{service:{navigation:_.qy,Hkb:_.HZv}}}constructor(a){super();this.Vb=a.service.navigation;this.Hkb=a.service.Hkb}updateLinks(a){_.lHe("q",a)}navigateTo(a,b=!1){this.Vb.navigateTo(a,b)}hideMobileModeSelector(){if(!_.vFe()){var a=_.jHe();a&&(a.style.display="none")}}showMobileModeSelector(){if(!_.vFe()){var a=_.jHe();a&&(a.style.display="")}}updateSrpSuggestionGroup(){}updateMagiStateParams(a){this.Hkb.updateMagiStateParams({hda:a})}fetch(a,b){return _.ntc(a,
{urlParams:b})}});

_.x();
});
// Google Inc.
