"use strict";loaded_g_0(function(_){var window=this;
_.u("pRMv2d");
_.zfb(_.TU,class extends _.Afb{static Kb(){return{}}constructor(){super();this.places=new Map;this.pa=null;this.Ha=new Set;this.Da=new Set;this.Ca=new Set;this.za=new Set;this.fa=!1;this.Eb=_.bq(this.fb,100,this)}va(a){return this.places.get(a)}ba(){return[...this.places.values()]}Ja(){this.fa=!1;this.places.clear()}da(...a){var b=!1;for(let c of a){let d=this.places.get(c.mid);d?(!d.latLng&&c.latLng&&(d.latLng=c.latLng,b=!0),!d.fprint&&c.fprint&&(d.fprint=c.fprint,b=!0),!d.categoryName&&c.categoryName&&
(d.categoryName=c.categoryName,b=!0),a=Object.fromEntries(Object.entries(c).filter(([e,f])=>!d[e]&&(f!==void 0||f!==""))),Object.assign(d,a)):this.places.set(c.mid,{...c});b=!0}b&&this.Eb()}aa(a){this.pa=a?{...a}:null;for(let b of this.Da)b(this.pa)}Ma(a){this.Da.add(a);this.pa&&a(this.pa)}Wa(a){this.Ha.add(a);var b=this.ba();b.length&&a(b)}jb(a){this.Ca.add(a);this.fa&&this.ba().filter(b=>!!b.latLng).length===0&&a()}ub(a){this.za.add(a);this.fa&&a()}oa(){this.fa=!0;this.ba().filter(a=>!!a.latLng).length===
0&&this.Ca.forEach(a=>void a());this.za.forEach(a=>void a())}fb(){var a=this.ba();if(a.length)for(let b of this.Ha)b(a)}});
_.N();
});
// Google Inc.
